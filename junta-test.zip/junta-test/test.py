url = 'http://127.0.0.1:5000/data'

# sample data
data = {"https://www.city-data.com/city/Alexandria-Virginia.html"}


def set_default(obj):
    if isinstance(obj, set):
        return list(obj)
    raise TypeError

import requests
import json

data = json.dumps(data,default=set_default)

send_request = requests.post(url, data)
print(send_request)
print(send_request.text)