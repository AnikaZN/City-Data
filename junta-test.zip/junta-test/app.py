from flask import Flask, jsonify, request
import pandas as pd

df = pd.read_csv('./anika_cities-Copy1.csv')

app = Flask(__name__)

@app.route("/")
def root():
    return ("hi")

@app.route("/data",methods=("GET","POST"))
def display_city():
    city = request.get_json(force=True)
    output = df[df['city'] == str(city)]
    output = output.to_dict()
    return jsonify(output=output)

if __name__ == "__main__":
    app.run()
